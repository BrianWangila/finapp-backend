<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['withdraw', 'Send', 'Receive']);
            $table->string('from_account');
            $table->string('name');
            $table->string('to_account');
            $table->decimal('amount', 10, 2);
            $table->string('type_of_purchase')->nullable();
            $table->string('bank_name')->nullable();
            $table->boolean('negative')->default(false);
            $table->string('logo')->nullable();
            $table->date('date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('transactions');
    }
};
